package com.openclassrooms.paymybuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymybuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
